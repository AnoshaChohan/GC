<!-- user.blade.php -->
@include('userInner')
