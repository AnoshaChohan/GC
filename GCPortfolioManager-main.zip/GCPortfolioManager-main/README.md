# GCPortfolioManager

# setup
Terminal
cd GCPortfolioManager
-composer install
-npm install && npm run dev

-php artisan migrate
-php artisan db:seed

# open project
-cd GCPortfolioManager
-npm run dev
-php artisan serve