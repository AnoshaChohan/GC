@extends('layouts.app')

@section('content')
<div class="centered-header">Contact Us</div>

<div class="contact-map" >
    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3984.2024488969414!2d101.79198191475703!3d3.040329147785908!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x31cc34a5f21a8235%3A0x78796ffc32ce3fcd!2z5ouJ5pu85aSn5a2m5Y-M5rqq6b6Z5qCh5Yy6!5e0!3m2!1szh-CN!2smy!4v1689136426926!5m2!1szh-CN!2smy" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
</div>    
<div class="contact-content">
    <p> If you have any enquiries, please contact our University</p><br>
    <p>Phone number: 03-90860288</p>
</div>

@endsection

