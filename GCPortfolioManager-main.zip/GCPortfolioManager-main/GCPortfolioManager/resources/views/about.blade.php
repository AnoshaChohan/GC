@extends('layouts.app')

@section('content')
<div class="centered-header">About Us</div>
<div class="about-p">
        <p>
            GC Portfolio System is a gold calculator system which can calculate <br>
            the profit of your gold portfolio when you key in the date you sell, the price of gold and exchange rate. <br>
            This system are developed by 4 UTAR students.
        </p>
</div>
@endsection