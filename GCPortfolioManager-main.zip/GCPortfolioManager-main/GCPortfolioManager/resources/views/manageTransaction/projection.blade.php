@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="header">
            <div class="centered-header">Projection</div>
        </div>
        <div class="col-md-5">
            <div class="card">
                <div class="card-header centered-text">Enter Expected Gold Transaction Termination</div>

                <div class="card-body">
                    <div class="body-header">
                        <div class="list">
                            <div class="item">
                                <span class="header">Terminate Date:</span>
                                <input type="date" class="text-input" placeholder="Select date"></input>
                            </div>
                            <div class="item">
                                <span class="header">QM Buy:</span>
                                <input type="text" class="text-input" placeholder="QM sell value"></input>
                            </div>
                            <div class="item">
                                <span class="header">FX:</span>
                                <input type="text" class="text-input" placeholder="FX value"></input>
                            </div>
                            <div class="centered-text">
                                <a type="button" id="myButton" class="btn btn-primary">Forcast</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

</div>
@endsection