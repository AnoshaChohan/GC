@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="header">
            <div class="centered-header">GC Portfolio Manager</div>
        </div>
        <div class="col-md-5">
            <div class="card">
                <div class="card-header centered-text">Enter Gold Transaction</div>

                <div class="card-body">
                    <div class="body-header">
                        <div class="list">
                            <div class="item">
                                <span class="header">Date:</span>
                                <input type="date" class="text-input" placeholder="Select date"></input>
                            </div>
                            <div class="item">
                                <span class="header">QM sell:</span>
                                <input type="text" class="text-input" placeholder="QM sell value"></input>
                            </div>
                            <div class="item">
                                <span class="header">FX:</span>
                                <input type="text" class="text-input" placeholder="FX value"></input>
                            </div>
                            <div class="item">
                                <span class="header">Downpayment:</span>
                                <input type="text" class="text-input" placeholder="Downpayment value"></input>
                            </div>
                            <div class="centered-text">
                                <a type="button" id="myButton" class="btn btn-primary">Save</a>
                            </div>
                            </div>
                    </div>
                </div>
            </div>

            <div class="table-container">
                <table class="centered-table">


                    <thead>

                        <tr>
                        <th></th>
                        <th colspan="4">Transaction History Details</th>
                        <th colspan="5">Expected Terminated Transaction History Details</th>
                        <th colspan="2">Action</th>
                        </tr>

                        <tr>
                        <th>ID</th>
                        <th>Date</th>
                        <th>QM Sell (RM/g)</th>
                        <th>FX</th>
                        <th>Downpayment</th>
                        <th>Downpayment</th>
                        <th>Termination Date</th>
                        <th>FX</th>
                        <th>QM Buy (RM/g)</th>
                        <th>Profit / Loss</th>
                        <th>Projection</th>
                        <th>Terminate</th>
                        </tr>

                    </thead>


                    <tbody>
                    <tr>
                        <td>1</td>
                        <td>2023-07-13</td>
                        <td>100</td>
                        <td>4.5</td>
                        <td>1000</td>
                        <td>300</td>
                        <td>2023-07-13</td>
                        <td>4.5</td>
                        <td>100</td>
                        <td>500</td>
                        <td><a type="button" id="myButton" class="btn btn-primary" href="../project">Project</a></td>
                        <td><button type="button" id="myButton" class="btn btn-danger" >Terminate</button></td>
                    </tr>

                        
                    </tbody>
                </table>    
            </div>
 
        </div>
        
    </div>

</div>

@endsection
