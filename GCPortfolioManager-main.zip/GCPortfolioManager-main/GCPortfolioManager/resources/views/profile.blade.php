@extends('layouts.app')

@section('content')
<!DOCTYPE html>
<html>
<head>
  <title>Profile Page</title>
  <link rel="stylesheet" type="text/css" href="{{ asset('css/styles.css') }}">
  <!-- Add Bootstrap CSS link here -->
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
  <div class="container">
    <div class="profile mt-5">
      <div class="text-center">
        <h1 class="mb-4">GC Portfolio Profile</h1>
      </div>
      <div class="row">
        <div class="col-md-12">
          <div class="card mb-4">
            <div class="card-header text-center">
              <h5 class="card-title">{{ Auth::user()->name }}</h5>
            </div>
            <div class="card-body">
              <p><strong>Email Address:</strong> {{ Auth::user()->email }}</p>
              <p><strong>Phone:</strong> {{ Auth::user()->phone }}</p>
              <p><strong>Role:</strong> {{ Auth::user()->role }}</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</body>
</html>
@endsection