@extends('layouts.app')

@section('content')
<div class="subscription-centered-header">Subscription Plans</div>
<body class="subscription-body">
    <div class="subscription-container">
    <div class="subscription-card">
      <h2 class="subscription-card-title">Free</h2>
      <div class="subscription-card-price">$0/month</div>
      <p class="subscription-card-description">Access to free features</p>
      <a href="#" class="subscription-card-button">Subscribe Now</a>
    </div>
    
    <div class="subscription-card">
      <h2 class="subscription-card-title">Basic</h2>
      <div class="subscription-card-price">$9.99/month</div>
      <p class="subscription-card-description">Access to basic features</p>
      <a href="#" class="subscription-card-button">Subscribe Now</a>
    </div>
    
    <div class="subscription-card">
      <h2 class="subscription-card-title">Premium</h2>
      <div class="subscription-card-price">$19.99/month</div>
      <p class="subscription-card-description">Access to premium features</p>
      <a href="#" class="subscription-card-button">Subscribe Now</a>
    </div>
  </div>
  </body>

@endsection